/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.projetopoo.model;

/**
 *
 * @author Matheus
 */
public class Funcionario extends Pessoa{
  
    public Funcionario(String nome){
        super(nome);
    }
      public void digitar() {
        System.out.println(nome + " esta digitando...");
  
     }
}