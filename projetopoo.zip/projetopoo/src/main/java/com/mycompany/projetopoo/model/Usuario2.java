/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.projetopoo.model;

/**
 *
 * @author Matheus
 */
public class Usuario2 extends Pessoa{
    
    public Usuario2(String nome){
        super(nome);
        
    }
    public void logar() {
        System.out.println(nome + " fez login no sistema...");
    }
    
}
  
