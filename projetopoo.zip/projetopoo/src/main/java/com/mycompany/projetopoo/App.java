/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.projetopoo;

import com.mycompany.projetopoo.model.Aluno;
import com.mycompany.projetopoo.model.Funcionario;
import com.mycompany.projetopoo.model.Pessoa;
import com.mycompany.projetopoo.model.Professor;
import com.mycompany.projetopoo.model.Usuario;
import com.mycompany.projetopoo.model.Usuario2;


/**
 *
 * @author Matheus
 */
public class App {

    public static void main(String[] args) {
        
            Pessoa p1 = new Pessoa("Matheus Henrique");
            Usuario u1 = new Usuario("Matheus Henrique");
            Aluno a1 = new Aluno("Matheus Henrique", "95463511");
            Funcionario f1 = new Funcionario("Jose Paulo");
            Usuario2 u2 = new Usuario2("Jose Paulo");
            Professor pf1 = new Professor("Jose Paulo", "57854470");
            
            
            p1.digitar();
            u1.logar();
            a1.mostrarRa();
            System.out.println("-----------------------------------------");
            f1.digitar();
            u2.logar();
            pf1.mostrarMatricula();
        }
    }

