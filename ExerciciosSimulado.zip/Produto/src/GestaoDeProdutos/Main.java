/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package GestaoDeProdutos;

/**
 *
 * @author Matheus
 */
public class Main {
      /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Produto p1 = new Produto("Smartphone", 2500.0, 10);
        Produto p2 = new Produto("Televisao", 3200.0, 5);
        Produto p3 = new Produto("Notebook", 4500.0, 8);

        // Exibindo informações diretamente
        System.out.println("Produto: " + p1.nome + " - Preco: R$" + p1.preco + " - Estoque: " + p1.quantidadeEstoque);
        System.out.println("Produto: " + p2.nome + " - Preco: R$" + p2.preco + " - Estoque: " + p2.quantidadeEstoque);
        System.out.println("Produto: " + p3.nome + " - Preco: R$" + p3.preco + " - Estoque: " + p3.quantidadeEstoque);
    }
}

