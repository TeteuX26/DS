/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package corrida;

/**
 *
 * @author Matheus
 */
public class Main {
     /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Corrida c1 = new Corrida();
        c1.distanciaPercorrida = 10.0;
        c1.tarifaBase = 5.0;
        c1.multiplicadorTarifa = 1.2;

        System.out.println("Valor total da corrida: R$ " + c1.calcularValorTotal());
    }
}
