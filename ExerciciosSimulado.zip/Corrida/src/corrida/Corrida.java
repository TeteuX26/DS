/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package corrida;

/**
 *
 * @author Matheus
 */
public class Corrida {
    double distanciaPercorrida;
    double tarifaBase;
    double multiplicadorTarifa;

    public double calcularValorTotal() {
        double precoPorKm = 2.5;
        return tarifaBase + (distanciaPercorrida * precoPorKm * multiplicadorTarifa);
    }
}
