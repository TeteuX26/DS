/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package aluno;

/**
 *
 * @author Matheus
 */
public class Main {
     /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Aluno a1 = new Aluno();
        a1.setMatricula("2025A01");
        a1.setNome("Pedro");
        a1.setNota(8.5);

        System.out.println(a1.getMatricula() + " - " + a1.getNome() + " - Nota: " + a1.getNota());
    }
}
