/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package pessoas;

/**
 *
 * @author Matheus
 */
class Professor extends Pessoas {
    String disciplina;
    double salario;

    Professor(String nome, String cpf, String dataNascimento, String disciplina, double salario) {
        super(nome, cpf, dataNascimento);
        this.disciplina = disciplina;
        this.salario = salario;
    }

    @Override
    void mostrarInfo() {
        super.mostrarInfo();
        System.out.println("Disciplina: " + disciplina + ", Salário: " + salario);
    }
}

