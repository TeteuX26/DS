/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package pessoas;

/**
 *
 * @author Matheus
 */
public class Pessoas {
String nome;
    String cpf;
    String dataNascimento;

    Pessoas(String nome, String cpf, String dataNascimento) {
        this.nome = nome;
        this.cpf = cpf;
        this.dataNascimento = dataNascimento;
    }

    void mostrarInfo() {
        System.out.println("Nome: " + nome + ", CPF: " + cpf + ", Data Nasc.: " + dataNascimento);
    }
}
