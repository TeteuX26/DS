/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package pessoas;

/**
 *
 * @author Matheus
 */
public class Main {
   /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
             Aluno a = new Aluno("Lucas", "12345678900", "01/01/2010", "A001", "5B");
        Professor p = new Professor("Maria", "98765432100", "15/05/1980", "Matemática", 5000);
        a.mostrarInfo();
        System.out.println("----------");
        p.mostrarInfo();
    }
}
