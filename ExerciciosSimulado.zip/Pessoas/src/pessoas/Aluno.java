/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package pessoas;

/**
 *
 * @author Matheus
 */
class Aluno extends Pessoas {
    String matricula;
    String turma;

    Aluno(String nome, String cpf, String dataNascimento, String matricula, String turma) {
        super(nome, cpf, dataNascimento);
        this.matricula = matricula;
        this.turma = turma;
    }

    @Override
    void mostrarInfo() {
        super.mostrarInfo();
        System.out.println("Matrícula: " + matricula + ", Turma: " + turma);
    }
}

