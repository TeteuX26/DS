/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package pessoas3;

/**
 *
 * @author Matheus
 */
public class Main {
  public static void main(String[] args) {
        Aluno aluno1 = new Aluno("Maria", "123.456.789-00", "2025001");
        Aluno aluno2 = new Aluno("Pedro", "987.654.321-00", "2025002");
        Professor professor1 = new Professor("Carlos", "111.222.333-44", "Matemática");
        Professor professor2 = new Professor("Ana", "555.666.777-88", "História");

        System.out.println("Alunos:");
        System.out.println(aluno1.getNome() + " - Matrícula: " + aluno1.getMatricula() + " - CPF: " + aluno1.getCpf());
        System.out.println(aluno2.getNome() + " - Matrícula: " + aluno2.getMatricula() + " - CPF: " + aluno2.getCpf());

        System.out.println("\nProfessores:");
        System.out.println(professor1.getNome() + " - Matéria: " + professor1.getMateria() + " - CPF: " + professor1.getCpf());
        System.out.println(professor2.getNome() + " - Matéria: " + professor2.getMateria() + " - CPF: " + professor2.getCpf());
    }
}