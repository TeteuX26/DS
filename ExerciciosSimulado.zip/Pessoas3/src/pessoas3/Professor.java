/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package pessoas3;

/**
 *
 * @author Matheus
 */
public class Professor extends Pessoas3 {
    private String materia;

    public Professor(String nome, String cpf, String materia) {
        super(nome, cpf);
        this.materia = materia;
    }

    public String getMateria() {
        return materia;
    }

    public void setMateria(String materia) {
        this.materia = materia;
    }
}