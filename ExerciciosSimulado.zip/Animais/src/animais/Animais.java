/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package animais;

/**
 *
 * @author Matheus
 */
public class Animais {
    String nome;
    double peso;
    double altura;

    Animais(String nome, double peso, double altura) {
        this.nome = nome;
        this.peso = peso;
        this.altura = altura;
    }

    double calcularIMC() {
        return peso / (altura * altura);
    }

    void mostrarInfo() {
        System.out.println("Animal: " + nome + ", IMC: " + calcularIMC());
    }
}

