/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package animais;

/**
 *
 * @author Matheus
 */
public class Main {
     public static void main(String[] args) {
        Animais a = new Animais("Spike", 20, 0.5);
        a.mostrarInfo();
    }
}


