/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package usuarios;

/**
 *
 * @author Matheus
 */
public class Usuarios {
    String nome;
    String tipoUsuario;

    Usuarios(String nome, String tipoUsuario) {
        this.nome = nome;
        this.tipoUsuario = tipoUsuario;
    }

    int calcularPrazoDevolucao() {
        switch (tipoUsuario.toLowerCase()) {
            case "professor":
                return 30;
            case "aluno":
                return 15;
            default:
                return 7;
        }
    }

    void mostrarInfo() {
        System.out.println("Nome: " + nome + ", Tipo: " + tipoUsuario +
                           ", Prazo de devolução: " + calcularPrazoDevolucao() + " dias");
    }
  }
  

