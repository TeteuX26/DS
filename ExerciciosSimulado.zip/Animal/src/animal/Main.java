/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package animal;

/**
 *
 * @author Matheus
 */
public class Main {
       /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Animal cachorro = new Animal();
        cachorro.nome = "Rex";
        cachorro.peso = 20.0;
        cachorro.altura = 0.5;

        System.out.println("IMC de " + cachorro.nome + ": " + cachorro.calcularIMC());
    }
    
}
