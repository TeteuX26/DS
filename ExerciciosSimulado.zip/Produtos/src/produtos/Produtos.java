/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package produtos;

/**
 *
 * @author Matheus
 */
public class Produtos {
    String nome;
    double preco;

    public double aplicarDesconto(int quantidade) {
        double desconto = 0.0;
        if (quantidade >= 10) {
            desconto = 0.15;
        } else if (quantidade >= 5) {
            desconto = 0.10;
        } else if (quantidade >= 3) {
            desconto = 0.05;
        }
        double total = preco * quantidade;
        return total - (total * desconto);
    }
}
