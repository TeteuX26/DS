/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package livros;

/**
 *
 * @author Matheus
 */
public class Main {
     public static void main(String[] args) {
        LivroFiccao ficcao = new LivroFiccao("O Senhor dos Anéis", "J.R.R. Tolkien", "Fantasia");
        LivrosNaoFiccao naoFiccao = new LivrosNaoFiccao("História do Brasil", "Boris Fausto", "História");

        System.out.println(ficcao.getTitulo() + " - " + ficcao.getAutor() + " - Gênero: " + ficcao.getGenero());
        System.out.println(naoFiccao.getTitulo() + " - " + naoFiccao.getAutor() + " - Assunto: " + naoFiccao.getAssunto());
    }
}
