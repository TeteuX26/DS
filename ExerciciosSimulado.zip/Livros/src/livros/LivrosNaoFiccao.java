/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package livros;

/**
 *
 * @author Matheus
 */
    public class LivrosNaoFiccao extends Livros {
    private String assunto;

    public LivrosNaoFiccao(String titulo, String autor, String assunto) {
        super(titulo, autor);
        this.assunto = assunto;
    }

    public String getAssunto() {
        return assunto;
    }

    public void setAssunto(String assunto) {
        this.assunto = assunto;
    }
}