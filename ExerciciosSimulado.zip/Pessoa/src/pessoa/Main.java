/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package pessoa;

/**
 *
 * @author Matheus
 */
public class Main {
      /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
         Aluno a = new Aluno();
        a.nome = "Lucas";
        a.idade = 16;
        a.matricula = "A123";

        Professor prof = new Professor();
        prof.nome = "Ana";
        prof.idade = 35;
        prof.disciplina = "Matematica";

        Funcionario f = new Funcionario();
        f.nome = "Jose";
        f.idade = 40;
        f.cargo = "Secretario";

        System.out.println(a.nome + " - " + a.matricula);
        System.out.println(prof.nome + " - " + prof.disciplina);
        System.out.println(f.nome + " - " + f.cargo);
    }
}
