/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package transporte;

/**
 *
 * @author Matheus
 */
class Aviao extends Transporte {
    double taxaDeAeroporto;

    Aviao(int capacidade, double precoBase, double taxaDeAeroporto) {
        super(capacidade, precoBase);
        this.taxaDeAeroporto = taxaDeAeroporto;
    }

    @Override
    double calcularValorPassagem() {
        return precoBase + taxaDeAeroporto;
    }
}
