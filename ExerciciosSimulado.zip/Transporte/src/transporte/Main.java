/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package transporte;

/**
 *
 * @author Matheus
 */
public class Main {
    public static void main(String[] args) {
        Transporte onibus = new Onibus(50, 100, 50);
        Transporte aviao = new Aviao(150, 300, 50);

        Viagem v1 = new Viagem("Rio de Janeiro", onibus);
        Viagem v2 = new Viagem("São Paulo", aviao);

        v1.mostrarInfo();
        v2.mostrarInfo();
    }
}
