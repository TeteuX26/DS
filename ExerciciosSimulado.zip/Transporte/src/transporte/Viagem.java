/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package transporte;

/**
 *
 * @author Matheus
 */
public class Viagem {
    String destino;
    Transporte transporte;

    Viagem(String destino, Transporte transporte) {
        this.destino = destino;
        this.transporte = transporte;
    }

    void mostrarInfo() {
        System.out.println("Destino: " + destino + " | Valor da passagem: " + transporte.calcularValorPassagem());
    }
}

