/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package transporte;

/**
 *
 * @author Matheus
 */
class Onibus extends Transporte {
    int numeroAssentos;

    Onibus(int capacidade, double precoBase, int numeroAssentos) {
        super(capacidade, precoBase);
        this.numeroAssentos = numeroAssentos;
    }

    @Override
    double calcularValorPassagem() {
        return precoBase + 10; // taxa extra
    }
}


