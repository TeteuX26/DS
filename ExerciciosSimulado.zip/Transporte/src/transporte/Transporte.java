/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package transporte;

/**
 *
 * @author Matheus
 */
public class Transporte {
    int capacidade;
    double precoBase;

    Transporte(int capacidade, double precoBase) {
        this.capacidade = capacidade;
        this.precoBase = precoBase;
    }

    double calcularValorPassagem() {
        return precoBase;
    }
}

