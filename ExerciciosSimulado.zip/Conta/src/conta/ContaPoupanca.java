/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package conta;

/**
 *
 * @author Matheus
 */
class ContaPoupanca extends Conta {
    double taxaDeJuros;

    ContaPoupanca(String numeroConta, double saldoInicial, double taxaDeJuros) {
        super(numeroConta, saldoInicial);
        this.taxaDeJuros = taxaDeJuros;
    }
}

