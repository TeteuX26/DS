/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package conta;

/**
 *
 * @author Matheus
 */
public class Main {
        public static void main(String[] args) {
        ContaCorrente cc = new ContaCorrente("1234", 1000, 500);
        ContaPoupanca cp = new ContaPoupanca("5678", 2000, 0.02);

        cc.depositar(500);
        cc.sacar(1800);
        cc.mostrarSaldo();

        cp.depositar(300);
        cp.sacar(1000);
        cp.mostrarSaldo();
    }
}

