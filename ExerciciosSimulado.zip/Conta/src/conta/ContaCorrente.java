/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package conta;

/**
 *
 * @author Matheus
 */
class ContaCorrente extends Conta {
    double limiteDeCredito;

    ContaCorrente(String numeroConta, double saldoInicial, double limiteDeCredito) {
        super(numeroConta, saldoInicial);
        this.limiteDeCredito = limiteDeCredito;
    }

    @Override
    void sacar(double valor) {
        if (valor <= saldo + limiteDeCredito) {
            saldo -= valor;
            System.out.println("Saque Conta Corrente: " + valor + " | Saldo atual: " + saldo);
        } else {
            System.out.println("Saldo + limite insuficiente!");
        }
    }
}
