/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package conta;

/**
 *
 * @author Matheus
 */
public class Conta {
    String numeroConta;
    double saldo;

    Conta(String numeroConta, double saldoInicial) {
        this.numeroConta = numeroConta;
        this.saldo = saldoInicial;
    }

    void depositar(double valor) {
        saldo += valor;
        System.out.println("Depósito: " + valor + " | Saldo atual: " + saldo);
    }

    void sacar(double valor) {
        if (valor <= saldo) {
            saldo -= valor;
            System.out.println("Saque: " + valor + " | Saldo atual: " + saldo);
        } else {
            System.out.println("Saldo insuficiente!");
        }
    }

    void mostrarSaldo() {
        System.out.println("Conta: " + numeroConta + " | Saldo: " + saldo);
    }
}
