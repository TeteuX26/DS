/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package funcionarios;

/**
 *
 * @author Matheus
 */
public class Main {
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
               Medico m = new Medico("Dr. Carlos", "M123", 12000, "CRM1234", "Cardiologia");
        Enfermeiro e = new Enfermeiro("Ana", "E456", 5000, "COREN5678");
        m.mostrarInfo();
        System.out.println("----------");
        e.mostrarInfo();
    }
}
