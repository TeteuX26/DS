/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package funcionarios;

/**
 *
 * @author Matheus
 */
public class Medico extends Funcionarios {
       String crm;
    String especialidade;

    Medico(String nome, String matricula, double salario, String crm, String especialidade) {
        super(nome, matricula, salario);
        this.crm = crm;
        this.especialidade = especialidade;
    }

    @Override
    void mostrarInfo() {
        super.mostrarInfo();
        System.out.println("CRM: " + crm + ", Especialidade: " + especialidade);
    }
}
