/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package funcionarios;

/**
 *
 * @author Matheus
 */
class Enfermeiro extends Funcionarios {
    String coren;

    Enfermeiro(String nome, String matricula, double salario, String coren) {
        super(nome, matricula, salario);
        this.coren = coren;
    }

    @Override
    void mostrarInfo() {
        super.mostrarInfo();
        System.out.println("COREN: " + coren);
    }
}
