/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package produtos2;

/**
 *
 * @author Matheus
 */
public class Produtos2 {

       String nome;
    double preco;

    Produtos2(String nome, double preco) {
        this.nome = nome;
        this.preco = preco;
    }

    double aplicarDesconto(int quantidade) {
        double desconto = 0;
        if (quantidade >= 5 && quantidade < 10) desconto = 0.05;
        else if (quantidade >= 10 && quantidade < 20) desconto = 0.10;
        else if (quantidade >= 20) desconto = 0.15;
        return preco * quantidade * (1 - desconto);
    }

    void mostrarInfo(int quantidade) {
        System.out.println("Produto: " + nome + ", Total com desconto: " + aplicarDesconto(quantidade));
    }
}

