/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package produtos2;

/**
 *
 * @author Matheus
 */
public class Main {
        public static void main(String[] args) {
        Produtos2 p = new Produtos2("Arroz", 10);
        p.mostrarInfo(8);
        p.mostrarInfo(12);
        p.mostrarInfo(25);
    }
}


