/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package contas;

/**
 *
 * @author Matheus
 */
public class ContaPoupanca extends Contas {
    private double taxaDeRendimento;

    public ContaPoupanca(String numero, double saldo, double taxa) {
        super(numero, saldo);
        this.taxaDeRendimento = taxa;
    }

    public double getTaxaDeRendimento() {
        return taxaDeRendimento;
    }

    public void setTaxaDeRendimento(double taxa) {
        this.taxaDeRendimento = taxa;
    }
}
