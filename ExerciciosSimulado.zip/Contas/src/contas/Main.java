/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package contas;

/**
 *
 * @author Matheus
 */
public class Main {
 public static void main(String[] args) {
        ContaCorrente contaCorrente = new ContaCorrente("12345-6", 1000.0, 500.0);
        ContaPoupanca contaPoupanca = new ContaPoupanca("98765-4", 2000.0, 0.05);

        contaCorrente.depositar(300.0);
        contaCorrente.sacar(150.0);
        contaPoupanca.depositar(500.0);

        System.out.println("Conta Corrente:");
        System.out.println("Número: " + contaCorrente.getNumero());
        System.out.println("Saldo: " + contaCorrente.getSaldo());
        System.out.println("Limite Cheque Especial: " + contaCorrente.getLimiteChequeEspecial());

        System.out.println("\nConta Poupança:");
        System.out.println("Número: " + contaPoupanca.getNumero());
        System.out.println("Saldo: " + contaPoupanca.getSaldo());
        System.out.println("Taxa de Rendimento: " + contaPoupanca.getTaxaDeRendimento());
    }
}