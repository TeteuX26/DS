/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package contato;

/**
 *
 * @author Matheus
 */
public class Main {
     /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Contato c1 = new Contato();
        c1.setNome("Ana");
        c1.setTelefone("9999-9999");
        c1.setEmail("ana@email.com");

        System.out.println(c1.getNome() + " - " + c1.getTelefone() + " - " + c1.getEmail());
    }
}
