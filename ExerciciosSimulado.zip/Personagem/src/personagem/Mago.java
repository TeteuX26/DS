/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package personagem;

/**
 *
 * @author Matheus
 */
class Mago extends Personagem {
    int mana;

    Mago(String nome, int nivel) {
        super(nome, nivel);
        this.mana = 100;
    }

    @Override
    void atacar() {
        System.out.println(nome + " lança magia!");
    }
}

