/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package personagem;

/**
 *
 * @author Matheus
 */
class Arqueiro extends Personagem {
    String tipoDeArco;

    Arqueiro(String nome, int nivel, String tipoDeArco) {
        super(nome, nivel);
        this.tipoDeArco = tipoDeArco;
    }

    @Override
    void atacar() {
        System.out.println(nome + " dispara flecha com o " + tipoDeArco + "!");
    }
}

