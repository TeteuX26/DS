/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package personagem;

/**
 *
 * @author Matheus
 */
public class Main {
        public static void main(String[] args) {
        Guerreiro g = new Guerreiro("Thor", 5);
        Mago m = new Mago("Merlin", 5);
        Arqueiro a = new Arqueiro("Robin", 5, "arco longo");

        g.atacar();
        m.atacar();
        a.atacar();
    }
}

