/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package personagem;

/**
 *
 * @author Matheus
 */
public class Personagem {
    String nome;
    int nivel;
    int vida;
    int forca;

    Personagem(String nome, int nivel) {
        this.nome = nome;
        this.nivel = nivel;
        this.vida = 100;
        this.forca = 10;
    }

    void atacar() {
        System.out.println(nome + " ataca!");
    }
}
