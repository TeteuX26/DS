/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package personagem;

/**
 *
 * @author Matheus
 */
class Guerreiro extends Personagem {
    Guerreiro(String nome, int nivel) {
        super(nome, nivel);
        this.vida = 120;
        this.forca = 15;
    }

    @Override
    void atacar() {
        System.out.println(nome + " golpeia com a espada!");
    }
}
