/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package contabancaria;

/**
 *
 * @author Matheus
 */
public class Main {
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        ContaBancaria conta = new ContaBancaria();
        conta.saldo = 1000.0;
        conta.limiteCredito = 500.0;

        double saque = 1200.0;
        System.out.println("Saque de R$" + saque + " eh possivel? " + conta.verificarSaque(saque));
    }
}
