/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package ControleDeDisciplinas;

/**
 *
 * @author Matheus
 */
public class Main {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Disciplina matematica = new Disciplina("Matematica", 80, "Prof. Joao");
        Disciplina portugues = new Disciplina("Portuguts", 60, "Profa. Maria");
        Disciplina historia = new Disciplina("Historia", 40, "Prof. Carlos");

        // Exibindo informações
        matematica.exibirInfo();
        System.out.println("---------------------------------");
        portugues.exibirInfo();
        System.out.println("---------------------------------");
        historia.exibirInfo();
    }
    
}
