/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ControleDeDisciplinas;

/**
 *
 * @author Matheus
 */
public class Disciplina {
    private String nome;
    private int cargaHoraria;
    private String professorResponsavel;

    public Disciplina(String nome, int cargaHoraria, String professorResponsavel) {
        this.nome = nome;
        this.cargaHoraria = cargaHoraria;
        this.professorResponsavel = professorResponsavel;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public int getCargaHoraria() {
        return cargaHoraria;
    }

    public void setCargaHoraria(int cargaHoraria) {
        this.cargaHoraria = cargaHoraria;
    }

    public String getProfessorResponsavel() {
        return professorResponsavel;
    }

    public void setProfessorResponsavel(String professorResponsavel) {
        this.professorResponsavel = professorResponsavel;
    }
    
    public void exibirInfo(){
        System.out.println("Nome: " + nome);
        System.out.println("Carga Horaria: " + cargaHoraria + " horas");
        System.out.println("Professor Responsavel: " + professorResponsavel);
    }
}
