/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package corridas;

/**
 *
 * @author Matheus
 */
public class Corridas {
    double distanciaPercorrida;
    double tarifaBase;
    double multiplicadorTarifa;

    Corridas(double distanciaPercorrida, double tarifaBase, double multiplicadorTarifa) {
        this.distanciaPercorrida = distanciaPercorrida;
        this.tarifaBase = tarifaBase;
        this.multiplicadorTarifa = multiplicadorTarifa;
    }

    double calcularValorTotal() {
        return tarifaBase + (distanciaPercorrida * multiplicadorTarifa);
    }

    void mostrarInfo() {
        System.out.println("Valor total da corrida: " + calcularValorTotal());
    }
}

