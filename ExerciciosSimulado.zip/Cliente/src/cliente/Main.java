/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package cliente;

/**
 *
 * @author Matheus
 */
public class Main {
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Cliente cli1 = new Cliente();
        cli1.setNome("Maria");
        cli1.setCpf("123.456.789-00");
        cli1.setEndereco("Rua A, 123");

        System.out.println(cli1.getNome() + " - " + cli1.getCpf() + " - " + cli1.getEndereco());
    }
}
