/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ProntuarioDePacientes;

/**
 *
 * @author Matheus
 */
public class Main {
     /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Paciente p1 = new Paciente ("Joao Silva", 35, "Consulta de rotina - 10/09/2025");
        Paciente p2 = new Paciente("Maria Oliveira", 28, "Exame de sangue - 15/09/2025");
        Paciente p3 = new Paciente("Carlos Souza", 42, "Retorno - 20/09/2025");
        
        p1.exibirInfo();
        System.out.println("-------------------------------------------------------");
        p2.exibirInfo();
        System.out.println("-------------------------------------------------------");
        p3.exibirInfo();
    }
    
}
