/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package ProntuarioDePacientes;

/**
 *
 * @author Matheus
 */
public class Paciente {
    private String nome;
    private int idade;
    private String historicoDeConsultas;

    public Paciente(String nome, int idade, String historicoDeConsultas) {
        this.nome = nome;
        this.idade = idade;
        this.historicoDeConsultas = historicoDeConsultas;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public int getIdade() {
        return idade;
    }

    public void setIdade(int idade) {
        this.idade = idade;
    }

    public String getHistoricoDeConsultas() {
        return historicoDeConsultas;
    }

    public void setHistoricoDeConsultas(String historicoDeConsultas) {
        this.historicoDeConsultas = historicoDeConsultas;
    }
    public void exibirInfo(){
        System.out.println("Nome: " + nome);
        System.out.println("Idade: " + idade);
        System.out.println("Historico de Consultas: " + historicoDeConsultas);
    }
    
}
