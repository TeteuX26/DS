/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package livro;

/**
 *
 * @author Matheus
 */
public class Main {
        /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Livro l1 = new Livro();
        l1.setTitulo("Dom Casmurro");
        l1.setAutor("Machado de Assis");
        l1.setAnoPublicacao(1899);

        System.out.println(l1.getTitulo() + " - " + l1.getAutor() + " - " + l1.getAnoPublicacao());
    }
}
