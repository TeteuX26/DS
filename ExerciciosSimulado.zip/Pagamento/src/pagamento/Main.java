/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package pagamento;

/**
 *
 * @author Matheus
 */
public class Main {
    
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        PagamentoCartao pc = new PagamentoCartao(150.0, "23/09/2025", "Pago", "1234 5678 9012 3456", "Visa");
        PagamentoPix pp = new PagamentoPix(200.0, "23/09/2025", "Pendente", "meuchave@pix.com");
        PagamentoBoleto pb = new PagamentoBoleto(300.0, "23/09/2025", "Pago", "12345678901234567890", "30/09/2025");

        pc.mostrarInfo();
        System.out.println();
        pp.mostrarInfo();
        System.out.println();
        pb.mostrarInfo();
    }
}
