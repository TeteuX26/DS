/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package pagamento;

/**
 *
 * @author Matheus
 */
class PagamentoCartao extends Pagamento {
    String numeroCartao;
    String bandeira;

    PagamentoCartao(double valor, String data, String status, String numeroCartao, String bandeira) {
        super(valor, data, status);
        this.numeroCartao = numeroCartao;
        this.bandeira = bandeira;
    }

    void mostrarInfo() {
        super.mostrarInfo();
        System.out.println("Cartão: " + numeroCartao + ", Bandeira: " + bandeira);
    }
}
