/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package pagamento;

/**
 *
 * @author Matheus
 */
public class PagamentoPix extends Pagamento {
        String chavePix;

    PagamentoPix(double valor, String data, String status, String chavePix) {
        super(valor, data, status);
        this.chavePix = chavePix;
    }

    void mostrarInfo() {
        super.mostrarInfo();
        System.out.println("Chave Pix: " + chavePix);
    }
}


