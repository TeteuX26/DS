/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package pagamento;

/**
 *
 * @author Matheus
 */
class PagamentoBoleto extends Pagamento {
    String codigoBarra;
    String dataVencimento;

    PagamentoBoleto(double valor, String data, String status, String codigoBarra, String dataVencimento) {
        super(valor, data, status);
        this.codigoBarra = codigoBarra;
        this.dataVencimento = dataVencimento;
    }

    void mostrarInfo() {
        super.mostrarInfo();
        System.out.println("Código de barras: " + codigoBarra + ", Vencimento: " + dataVencimento);
    }
}
