/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package pagamento;

/**
 *
 * @author Matheus
 */
public class Pagamento {
double valor;
    String data;
    String status;

    Pagamento(double valor, String data, String status) {
        this.valor = valor;
        this.data = data;
        this.status = status;
    }

    void mostrarInfo() {
        System.out.println("Valor: " + valor + ", Data: " + data + ", Status: " + status);
    }
}


