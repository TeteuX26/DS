/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package GestaoDeVeiculos;

/**
 *
 * @author Matheus
 */
public class Main {
     /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Veiculo carro = new Veiculo ("Fiat Strada", "ABC4321", 650);
        Veiculo moto = new Veiculo ("Honda CG", "DEF-5678", 50);
        Veiculo caminhao = new Veiculo ("Volvo FH", "XYZ9876", 18000);
        
         carro.exibirInfo();
         System.out.println("----------------------------");
         moto.exibirInfo();
         System.out.println("----------------------------");
         caminhao.exibirInfo();
    }
}
