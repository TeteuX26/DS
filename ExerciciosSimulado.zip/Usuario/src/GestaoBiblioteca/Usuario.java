/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package GestaoBiblioteca;

/**
 *
 * @author Matheus
 */
public class Usuario {
    String nome;
    String tipoUsuario;
    
    public int calcularPrazoDevolucao(){
        if(tipoUsuario.equalsIgnoreCase("Professor")){
            return 30;
        }else if(tipoUsuario.equalsIgnoreCase("Aluno")){
            return 15;
        }else{
            return 7;
            
        }
    }
}
