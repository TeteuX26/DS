/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package GestaoBiblioteca;

/**
 *
 * @author Matheus
 */
public class Main {
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Usuario u1 = new Usuario();
        u1.nome = "Carlos";
        u1.tipoUsuario = "Visitante";
        
        System.out.println(u1.nome + " deve devolver o livro em " + u1.calcularPrazoDevolucao() + " dias");
    }
}
