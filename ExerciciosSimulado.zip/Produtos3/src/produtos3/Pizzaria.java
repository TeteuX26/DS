/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package produtos3;

/**
 *
 * @author Matheus
 */
    public class Pizzaria extends Restaurante {
    private String tipoDeForno;

    public Pizzaria(String nome, String endereco, String tipoDeForno) {
        super(nome, endereco);
        this.tipoDeForno = tipoDeForno;
    }

    public String getTipoDeForno() {
        return tipoDeForno;
    }
  }

