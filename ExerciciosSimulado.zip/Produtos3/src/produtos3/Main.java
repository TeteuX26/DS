/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package produtos3;

import java.util.ArrayList;
import java.util.List;

public class Main {
    public static void main(String[] args) {
        Produtos3 pizza = new Produtos3(1, "Pizza de Calabresa", 35.0);
        Produtos3 hamburguer = new Produtos3(2, "Hambúrguer Artesanal", 25.0);
        Produtos3 refrigerante = new Produtos3(3, "Refrigerante 500ml", 7.0);

        Cliente cliente1 = new Cliente("João", "Rua das Flores, 123");

        List<Produtos3> produtosPedido = new ArrayList<>();
        produtosPedido.add(pizza);
        produtosPedido.add(refrigerante);

        Pedido pedido1 = new Pedido(cliente1, produtosPedido);

        System.out.println("Cliente: " + pedido1.getCliente().getNome());
        System.out.println("Endereço: " + pedido1.getCliente().getEndereco());
        System.out.println("Total do pedido: R$ " + pedido1.calcularTotal());

        pedido1.adicionarProduto(hamburguer);
        System.out.println("Total do pedido após adicionar hambúrguer: R$ " + pedido1.calcularTotal());

        Pizzaria pizzaria = new Pizzaria("Pizzaria Bella", "Rua das Pizzas, 50", "Forno a Lenha");
        Hamburgueria hamburgueria = new Hamburgueria("Burger Town", "Av. dos Burgers, 200", true);

        System.out.println("\nRestaurantes:");
        System.out.println("Pizzaria: " + pizzaria.getNome() + ", Endereço: " + pizzaria.getEndereco() + ", Tipo de Forno: " + pizzaria.getTipoDeForno());
        System.out.println("Hamburgueria: " + hamburgueria.getNome() + ", Endereço: " + hamburgueria.getEndereco() + ", Drive Thru: " + hamburgueria.hasDriveThru());
    }
}