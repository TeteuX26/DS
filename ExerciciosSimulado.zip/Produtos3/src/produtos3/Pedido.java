/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package produtos3;

import java.util.List;

/**
 *
 * @author Matheus
 */
public class Pedido {
 private List<Produtos3> produtos;
    private Cliente cliente;

    public Pedido(Cliente cliente, List<Produtos3> produtos) {
        this.cliente = cliente;
        this.produtos = produtos;
    }

    public double calcularTotal() {
        double total = 0;
        for (Produtos3 p : produtos) {
            total += p.getPreco();
        }
        return total;
    }

    public void adicionarProduto(Produtos3 produto) {
        produtos.add(produto);
    }

    public void removerProduto(Produtos3 produto) {
        produtos.remove(produto);
    }

    public Cliente getCliente() {
        return cliente;
    }

    public List<Produtos3> getProdutos() {
        return produtos;
    }
}