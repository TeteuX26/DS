/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package produtos3;

/**
 *
 * @author Matheus
 */
public class Hamburgueria extends Restaurante {
    private boolean driveThru;

    public Hamburgueria(String nome, String endereco, boolean driveThru) {
        super(nome, endereco);
        this.driveThru = driveThru;
    }

    public boolean hasDriveThru() {
        return driveThru;
    }
}
