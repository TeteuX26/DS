/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package GestaoSalaDeCinema;

/**
 *
 * @author Matheus
 */
public class Main {
      /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        SalaDeCinema s1 = new SalaDeCinema(1, 150, "2D");
        SalaDeCinema s2 = new SalaDeCinema(2, 200, "3D");
        SalaDeCinema s3 = new SalaDeCinema(3, 300, "IMAX");

        System.out.println("Sala " + s1.numero + " - Capacidade: " + s1.capacidade + " pessoas - Tecnologia: " + s1.tipoTecnologia);
        System.out.println("Sala " + s2.numero + " - Capacidade: " + s2.capacidade + " pessoas - Tecnologia: " + s2.tipoTecnologia);
        System.out.println("Sala " + s3.numero + " - Capacidade: " + s3.capacidade + " pessoas - Tecnologia: " + s3.tipoTecnologia);
    }
}
