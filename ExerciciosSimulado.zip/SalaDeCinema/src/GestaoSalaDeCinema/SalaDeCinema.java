/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package GestaoSalaDeCinema;

/**
 *
 * @author Matheus
 */
public class SalaDeCinema {
    int numero;
    int capacidade;
    String tipoTecnologia;

    public SalaDeCinema(int numero, int capacidade, String tipoTecnologia) {
        this.numero = numero;
        this.capacidade = capacidade;
        this.tipoTecnologia = tipoTecnologia;
        
        
    }
}


  
    

