/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package funcionario;

/**
 *
 * @author Matheus
 */
public class Main {
     /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Funcionario f1 = new Funcionario();
        f1.setNome("Joao");
        f1.setCargo("Analista");
        f1.setSalario(3500.0);

        System.out.println(f1.getNome() + " - " + f1.getCargo() + " - R$" + f1.getSalario());
    }
}
