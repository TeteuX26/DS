/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package veiculos;

/**
 *
 * @author Matheus
 */
public class Veiculos {
    String modelo;
    String placa;
    int ano;

    Veiculos(String modelo, String placa, int ano) {
        this.modelo = modelo;
        this.placa = placa;
        this.ano = ano;
    }

    void mostrarInfo() {
        System.out.println("Modelo: " + modelo + ", Placa: " + placa + ", Ano: " + ano);
    }
}

   

