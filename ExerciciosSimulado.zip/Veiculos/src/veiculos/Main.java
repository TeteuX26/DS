/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package veiculos;

/**
 *
 * @author Matheus
 */
public class Main {
        public static void main(String[] args) {
        Carro c = new Carro("Honda Civic", "ABC-1234", 2020, 4);
        Moto m = new Moto("Yamaha R1", "XYZ-5678", 2021, 1000);
        c.mostrarInfo();
        System.out.println("----------");
        m.mostrarInfo();
    }
}


