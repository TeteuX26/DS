/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package veiculos;

/**
 *
 * @author Matheus
 */
class Moto extends Veiculos {
    int cilindradas;

    Moto(String modelo, String placa, int ano, int cilindradas) {
        super(modelo, placa, ano);
        this.cilindradas = cilindradas;
    }

    @Override
    void mostrarInfo() {
        super.mostrarInfo();
        System.out.println("Cilindradas: " + cilindradas);
    }
}

