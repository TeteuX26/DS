/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package veiculos;

/**
 *
 * @author Matheus
 */
class Carro extends Veiculos {
    int numeroPortas;

    Carro(String modelo, String placa, int ano, int numeroPortas) {
        super(modelo, placa, ano);
        this.numeroPortas = numeroPortas;
    }

    @Override
    void mostrarInfo() {
        super.mostrarInfo();
        System.out.println("Número de portas: " + numeroPortas);
    }
}
