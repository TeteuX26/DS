/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package funcionarios2;

/**
 *
 * @author Matheus
 */
class CameraMan extends Funcionarios2 {
    String tipoCamera;
    int tempoExperiencia;

    CameraMan(String nome, String matricula, double salario, String tipoCamera, int tempoExperiencia) {
        super(nome, matricula, salario);
        this.tipoCamera = tipoCamera;
        this.tempoExperiencia = tempoExperiencia;
    }

    void mostrarInfo() {
        super.mostrarInfo();
        System.out.println("Tipo de câmera: " + tipoCamera + ", Experiência: " + tempoExperiencia + " anos");
    }
}
