/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package funcionarios2;

/**
 *
 * @author Matheus
 */
public class Funcionarios2 {
    String nome;
    String matricula;
    double salario;

    Funcionarios2(String nome, String matricula, double salario) {
        this.nome = nome;
        this.matricula = matricula;
        this.salario = salario;
    }

    void mostrarInfo() {
        System.out.println("Nome: " + nome + ", Matrícula: " + matricula + ", Salário: " + salario);
    }
}


