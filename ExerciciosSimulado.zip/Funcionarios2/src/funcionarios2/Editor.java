/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package funcionarios2;

/**
 *
 * @author Matheus
 */
class Editor extends Funcionarios2 {
    String softwareEdicao;

    Editor(String nome, String matricula, double salario, String softwareEdicao) {
        super(nome, matricula, salario);
        this.softwareEdicao = softwareEdicao;
    }

    void mostrarInfo() {
        super.mostrarInfo();
        System.out.println("Software de edição: " + softwareEdicao);
    }
}

