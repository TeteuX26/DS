/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package funcionarios2;

/**
 *
 * @author Matheus
 */
public class Main {
        public static void main(String[] args) {
        Reporter r = new Reporter("Ana", "R001", 3000, "Política", 12);
        CameraMan c = new CameraMan("Bruno", "C001", 2500, "Canon", 5);
        Editor e = new Editor("Carlos", "E001", 2800, "Premiere");

        r.mostrarInfo();
        System.out.println();
        c.mostrarInfo();
        System.out.println();
        e.mostrarInfo();
    }
}


