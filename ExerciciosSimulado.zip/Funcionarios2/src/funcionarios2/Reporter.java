/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package funcionarios2;

/**
 *
 * @author Matheus
 */
    class Reporter extends Funcionarios2 {
    String areaAtuacao;
    int numeroReportagens;

    Reporter(String nome, String matricula, double salario, String areaAtuacao, int numeroReportagens) {
        super(nome, matricula, salario);
        this.areaAtuacao = areaAtuacao;
        this.numeroReportagens = numeroReportagens;
    }

    void mostrarInfo() {
        super.mostrarInfo();
        System.out.println("Área de atuação: " + areaAtuacao + ", Número de reportagens: " + numeroReportagens);
    }
}


