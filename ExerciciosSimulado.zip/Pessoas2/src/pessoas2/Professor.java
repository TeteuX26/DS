/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package pessoas2;

/**
 *
 * @author Matheus
 */
class Professor extends Pessoas2 {
   private double salario;
    private String disciplina;

    public Professor(String nome, String cpf, double salario, String disciplina) {
        super(nome, cpf);
        this.salario = salario;
        this.disciplina = disciplina;
    }

    public void registrarNota(Aluno aluno, double nota) {
        aluno.adicionarNota(nota);
    }

    public double getSalario() {
        return salario;
    }

    public String getDisciplina() {
        return disciplina;
    }
}
