/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package pessoas2;

/**
 *
 * @author Matheus
 */
public class Main {
      public static void main(String[] args) {
        Aluno aluno1 = new Aluno("Maria", "123.456.789-00", "2025001");
        Aluno aluno2 = new Aluno("Pedro", "987.654.321-00", "2025002");

        Professor prof1 = new Professor("Carlos", "111.222.333-44", 3500.0, "Matemática");

        Disciplina matematica = new Disciplina("Matemática", 60);

        prof1.registrarNota(aluno1, 8.5);
        prof1.registrarNota(aluno1, 7.0);
        prof1.registrarNota(aluno2, 9.0);
        prof1.registrarNota(aluno2, 6.5);

        matematica.emitirBoletim(aluno1);
        matematica.emitirBoletim(aluno2);
    }
}