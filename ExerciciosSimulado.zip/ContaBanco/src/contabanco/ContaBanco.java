/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package contabanco;

/**
 *
 * @author Matheus
 */
public class ContaBanco {

        double saldo;
    double limiteCredito;

    ContaBanco(double saldo, double limiteCredito) {
        this.saldo = saldo;
        this.limiteCredito = limiteCredito;
    }

    boolean verificarSaque(double valor) {
        return valor <= (saldo + limiteCredito);
    }

    void mostrarInfo() {
        System.out.println("Saldo: " + saldo + ", Limite: " + limiteCredito);
    }
}

