/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package funcionarios3;
/**
 *
 * @author Matheus
 */
public class Main {
    public static void main(String[] args) {
        Gerente g1 = new Gerente("Carlos", 5000, 1000);
        Desenvolvedor d1 = new Desenvolvedor("Ana", 4000, "Java");

        System.out.println(g1.getNome() + " - Salário: " + g1.getSalario() + " - Bônus: " + g1.getBonusAnual());
        System.out.println(d1.getNome() + " - Salário: " + d1.getSalario() + " - Linguagem: " + d1.getLinguagem());
    }
}