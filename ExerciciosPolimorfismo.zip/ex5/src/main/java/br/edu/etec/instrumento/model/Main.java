/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package br.edu.etec.instrumento.model;

/**
 *
 * @author mathe
 */
public class Main {

    public static void main(String[] args) {
       InstrumentoMusical g1 = new Guitarra();
        InstrumentoMusical p1 = new Piano();
        
        g1.tocar();
        p1.tocar();
    }
}