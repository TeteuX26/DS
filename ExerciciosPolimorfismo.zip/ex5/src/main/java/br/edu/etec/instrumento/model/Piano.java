/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package br.edu.etec.instrumento.model;

/**
 *
 * @author mathe
 */
public class Piano implements InstrumentoMusical {
    
    @Override
    public void tocar() {
        System.out.println("O piano está tocando uma bela melodia classica!");
    }
}
