package br.edu.etec.animal.model;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */



import br.edu.etec.animal.model.Animal;
import br.edu.etec.animal.model.Cachorro;
import br.edu.etec.animal.model.Gato;

/**
 *
 * @author mathe
 */
public class Main {
     public static void main(String[] args) {
        Animal a1 = new Cachorro();
        Animal a2 = new Gato();
        Animal a3 = new Animal();
        
        a1.fazerSom();
        a2.fazerSom();
        a3.fazerSom();
    }
}

        
        