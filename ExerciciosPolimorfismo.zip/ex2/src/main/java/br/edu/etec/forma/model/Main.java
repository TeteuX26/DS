/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package br.edu.etec.forma.model;

/**
 *
 * @author mathe
 */
public class Main {

    public static void main(String[] args) {
      Forma[] formas = {
          new Circulo (5),
          new Retangulo (7, 9),
          new Circulo (6.9),
          new Retangulo (9, 2)
      };
      
      for (int i = 0; i < formas.length; i++) {
            System.out.printf("Forma %d: area = %.2f%n", i + 1, formas[i].calcularArea());
    }
  }
}