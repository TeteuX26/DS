/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package br.edu.etec.funcionario.model;

/**
 *
 * @author mathe
 */
public class Vendedor extends Funcionario {
    private double comissao; 

    public Vendedor(String nome, int salarioBase, int par1) {
        super(nome, salarioBase);
        this.comissao = comissao;
    }

    @Override
    public double calcularSalario() {
        return salarioBase + comissao;
    }
    
}
