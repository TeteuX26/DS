/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package br.edu.etec.funcionario.model;

/**
 *
 * @author mathe
 */
public class Main {

    public static void main(String[] args) {
        Funcionario gerente = new Gerente("Joao", 5000, 1500);
        Funcionario vendedor = new Vendedor("Maria", 2500, 800);

        System.out.println(gerente.nome + " - Salario: R$ " + gerente.calcularSalario());
        System.out.println(vendedor.nome + " - Salario: R$ " + vendedor.calcularSalario());
    }
}
