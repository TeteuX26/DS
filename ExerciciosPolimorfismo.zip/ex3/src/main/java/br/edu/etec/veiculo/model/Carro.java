/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package br.edu.etec.veiculo.model;

/**
 *
 * @author mathe
 */
public class Carro extends Veiculo{
    
     @Override
     public void mover(){
         System.out.println("O carro esta se movendo pela estrada...");
     } 
}
