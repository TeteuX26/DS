/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package br.edu.etec.veiculo.model;

/**
 *
 * @author mathe
 */
public class Main {

    public static void main(String[] args) {
        Veiculo c1 = new Carro();
        Veiculo b1 = new Bicicleta();
        
        c1.mover();
        b1.mover();
       
    }
}
